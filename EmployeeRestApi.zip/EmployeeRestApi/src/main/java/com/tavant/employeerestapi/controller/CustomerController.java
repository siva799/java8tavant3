package com.tavant.employeerestapi.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.employeerestapi.exception.EmployeeNotFoundException;
import com.tavant.employeerestapi.exception.NoDataFoundException;
import com.tavant.employeerestapi.exception.NoDataFoundException1;
import com.tavant.employeerestapi.model.Customer;
import com.tavant.employeerestapi.repository.CustomerRepository;


@RestController
@RequestMapping("/api/customers")
// here we have the resources for employee
public class CustomerController {
	
	@Autowired
	CustomerRepository customerRepository;
	@GetMapping
	public String getCustomers() {
		return "hello";
	}
	
	@GetMapping("/all")
	public List<Customer> getAllOders() throws NoDataFoundException1 {
//	return Optional.ofNullable(employeeRepository.
//			findAll()).orElseThrow(()
//					->new NoDataFoundException("record not found"));
      if(customerRepository.findAll().isEmpty())
      {
    	  throw new NoDataFoundException1("no records found");
      }
      return customerRepository.findAll();
	}
	
	
	
	
	
	//can we retrive the specific id record
	@GetMapping("/{id}")
	public ResponseEntity<?> getCustomersById(@PathVariable("id")Integer id) throws EmployeeNotFoundException {
		Optional<Customer> optional = customerRepository.findById(id);
		 
		if(optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		}  
		else {
//			return ResponseEntity.status(HttpStatus.NOT_FOUND).
//					body(new EmployeeNotFoundException("Not found"));
			
			throw new EmployeeNotFoundException("no record found");
		}
		
	}
	
	@PostMapping  //transforming JSON java object
	//jackson api will take care implicity
public Customer addCustomers(@RequestBody @Valid Customer customers) throws EmployeeNotFoundException {
		
		return customerRepository.save(customers);
		//we can provide blank object....{}-blank object
//		if(true ){//customers.getCustomerId()==null) {
//			throw new EmployeeNotFoundException("provide the employee ");
//		}
//		else {
//			return customerRepository.save(customers);
//		}
//		
	}

	@DeleteMapping("/{id}")
	public Map<String, Boolean> deleteCustomer(@PathVariable(value = "id") Integer customerId)
	  throws EmployeeNotFoundException {
	 Customer customer = customerRepository.findById(customerId)
	   .orElseThrow(() -> new EmployeeNotFoundException("Employee not found for this id :: " + customerId));

	 customerRepository.delete(customer);
	 Map<String, Boolean> response = new HashMap<>();
	 response.put("deleted", Boolean.TRUE);
	 return response;
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Customer> updateCustomers(@PathVariable(value = "id") Integer customerId,
	  @Valid @RequestBody Customer customerDetails) throws EmployeeNotFoundException {
	 Customer customer = customerRepository.findById(customerId)
	 .orElseThrow(() -> new EmployeeNotFoundException("Employee not found for this id :: " + customerId));

	 
	
	 final Customer updatedCustomers = customerRepository.save(customer);
	 return ResponseEntity.ok(updatedCustomers);
	}
}