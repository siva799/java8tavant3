package com.tavant.employeerestapi.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.employeerestapi.exception.EmployeeNotFoundException;
import com.tavant.employeerestapi.exception.NoDataFoundException;
import com.tavant.employeerestapi.model.Employee;
import com.tavant.employeerestapi.repository.EmployeeRepository;

//to perform the controller if we are using spring MVC
//then we will use the @controller
//but here we are using rest then
//we should use @RestController
//this annotation is introduced from spring mvc version 4.x
//before spring 3.0 it is combination of @ResponseEntity and @controller
//in 4.0 they form @Restcontroller
//when we will deal with any rest application there we have to send the response
//will be on json,html,xml or any file
//whenever we have to share the data there we have to mark @ResponseEntity
//then what they have done instead of marking it on each and every method
//they come up with the solution @RestController

@RestController
@RequestMapping("/api/employee")
//here we have resource for employee
public class EmployeeController {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@GetMapping
	public String getEmployee() {
		return "hello";
	}
	
	@GetMapping("/all")
	public List<Employee> getAllEmployees() throws NoDataFoundException{
		//return employeeRepository.findAll();
//		return Optional.ofNullable(employeeRepository.findAll()).orElseThrow(
//						()->new NoDataFoundException("no record found"));
		
		throw new NoDataFoundException("no record found");
	}
	
	//we can retrieve the specific id record
	@GetMapping("/{id}")
	public ResponseEntity<?> getEmployeeById(@PathVariable("id") Integer id) throws EmployeeNotFoundException {
		//return employeeRepository.findById(id).get();
//		return employeeRepository.findById(id).
//				orElseThrow(()->new EmployeeNotFoundException("record not found"));
		Optional<Employee> optional = employeeRepository.findById(id);
		
		if(optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		}
		else {
			//return ResponseEntity.status(HttpStatus.NOT_FOUND).body("record not found");
//			return ResponseEntity.status(HttpStatus.NOT_FOUND).
//					body(new EmployeeNotFoundException("not found"));
			throw new EmployeeNotFoundException("record not found");
		}
	}
	
	@PostMapping//transfroming json ==> java object
	//jackson api will take care implicitly
	public Employee addEmployee( @RequestBody @Valid Employee employee) throws EmployeeNotFoundException {
		return employeeRepository.save(employee);
		
		//we can provide blank object....{}-blank object
//		if(employee.getEmployeeId()==null) {
//			throw new EmployeeNotFoundException("provide the employee ");
//		}
//		else {
//			return employeeRepository.save(employee);
//		}
		
	}
	


}
