package com.tavant.employeerestapi.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name =  "Order")
@Table(name = "orders")
public class Orders {
	
	@Id
	private Integer orderNumber;
	@NotBlank(message = "cannot be blank")
	private Date orderDate;
	private Date requiredDate;
	private Date shippedDate;
	@NotBlank(message = "status cannot be blank")
	private String status;
	private String comments;
	private Integer customerNumber;

}
