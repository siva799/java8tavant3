package com.tavant.employeerestapi.model;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "customers")
public class Customer {

	@Id
	private Integer customerNumber;
	private String customerName;
	@NotBlank(message = "lastname should not be blank")
	private String contactLastName;
	@NotBlank(message = "firstname should not be blank")
	private String contactFirstName;
	@NotBlank(message = "phone number should not be blank")
	private String phone;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String postalCode;
	private String country;
	private Integer salesRepEmployeeNumber;
	private BigDecimal creditLimit;
}
