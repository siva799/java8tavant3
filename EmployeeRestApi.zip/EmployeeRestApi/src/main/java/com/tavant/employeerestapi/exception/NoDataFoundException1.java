package com.tavant.employeerestapi.exception;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class NoDataFoundException1 extends Exception {
	public NoDataFoundException1(String message) {
		super(message);
		
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString() + this.getMessage();
	}

}
