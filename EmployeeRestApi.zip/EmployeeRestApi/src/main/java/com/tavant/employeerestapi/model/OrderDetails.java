package com.tavant.employeerestapi.model;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity(name =  "OrderDetails")
@Table(name = "orderdetails")
public class OrderDetails {
	@Id
	private Integer orderNumber;
	@NotBlank(message = "productcode cannot be blank")
	private String productCode;
	private Integer quantityOrdered;
	private BigDecimal priceEach;
	private Integer orderLineNumber;
	public static boolean addOrderDetail(OrderDetails orders) {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}
