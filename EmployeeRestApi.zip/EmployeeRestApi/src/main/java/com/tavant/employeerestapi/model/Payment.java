package com.tavant.employeerestapi.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
@Entity(name = "Payment")
@Table(name="payment")
public class Payment {
	@Id
	private String customerNumber;
	@NotBlank(message = "checkNumber cannot be blank")
	private String checkNumber;
	private Date paymentDate;
	private Double amount;

}
