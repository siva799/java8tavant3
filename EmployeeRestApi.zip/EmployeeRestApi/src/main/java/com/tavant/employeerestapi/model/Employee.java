package com.tavant.employeerestapi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.transaction.TransactionScoped;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.ManyToAny;
import org.hibernate.validator.constraints.Length;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Component
@Entity(name =  "Employee")
@Table(name = "employees")
public class Employee  {
	
	
	@Id @Column(name = "employeeNumber")
	private Integer employeeId;
	
	@Column(length = 20 , name = "firstName") @Size(max = 20)
	@NotBlank(message = "firstname should not be blank")
	private String firstName;
	
	@Column(length = 20) @Size(max = 20)
	@NotBlank(message = "lastname should not be blank")
	private String lastName;
	
//	@Column(length = 10) @Size(max = 10)
	@Transient
	@NotBlank(message = "extension should be provided")
	private String extension;
	
	@Column(length = 40 , nullable = false) @Size(max = 40)
	@NotBlank(message = "email should not be blank")
	@Email(message = "email should be valid")
	private String email;
	
	
	
	
	@JoinColumn(name = "officeCode")
	@Max(message = "custom message" ,value = 123)
	@Min(9)
	@NotNull(message = "office code should not be blank")
	private Integer officeCode;
	
	private Integer reportsTo;
	
	@Column(length = 20) @Size(max = 25)
	private String jobTitle;
	
	
	
	
	
}
